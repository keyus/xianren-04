# vue-webpack-demo
一个vue2.x 与 webpack 3.x  的项目配置 demo.,打算做成一个用于管理用台的，前端工程
# 金融网站APP，移动端
- 大概只有11个页面左右.
# 技术战
- webpack
- pug 也就是以前的jade
- scss
- es6
- postcss 自动处理css兼容,前缀
# 说明
- dist 编译生成的前端文件目录，可直接提供后端使用
# 运行
- npm install         #安装依赖
- npm build           #编译dist目录文件
- npm run start       #启动热更新服务器