import 'weui/dist/style/weui.css'
import './sass/common.scss';
import  './images.js';

